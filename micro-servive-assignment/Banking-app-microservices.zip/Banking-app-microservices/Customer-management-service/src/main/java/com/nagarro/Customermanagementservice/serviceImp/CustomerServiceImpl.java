package com.nagarro.Customermanagementservice.serviceImp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagarro.Customermanagementservice.exception.CustomException;
import com.nagarro.Customermanagementservice.exception.CustomerNotFoundException;
import com.nagarro.Customermanagementservice.feign.CustomerInterface;
import com.nagarro.Customermanagementservice.models.Customer;
import com.nagarro.Customermanagementservice.repo.CustomerDao;

@Service
public class CustomerServiceImpl {

	private CustomerDao repo;
	private CustomerInterface custInterface;

	@Autowired
	public CustomerServiceImpl(CustomerDao repo, CustomerInterface custInterface) {
		this.repo = repo;
		this.custInterface = custInterface;
	}

	public Customer create(Customer customer) {
		try {
			return repo.save(customer);
		} catch (Exception ex) {
			throw new CustomException("Error Creating Customer");
		}

	}

	public List<Customer> getCustomers() {
		try {
			return repo.findAll();
		} catch (Exception ex) {
			throw new CustomException("Error Getting Customers");
		}
	}

	public Customer getCustomer(Long id) {
		Customer customer = repo.findById(id)
				.orElseThrow(() -> new CustomerNotFoundException("Customer not found with ID: " + id));

		return customer;
	}

	public boolean isCustomerPresent(Long id) {
		repo.findById(id).orElseThrow(() -> new CustomerNotFoundException("Customer not found with ID: " + id));
		return true;
	}

	public Customer updateCustomer(Customer customer) {
		Long id = customer.getId();
		Customer existingCustomer = repo.findById(id)
				.orElseThrow(() -> new CustomerNotFoundException("Customer not found with ID: " + id));

		existingCustomer.setEmail(customer.getEmail());
		existingCustomer.setName(customer.getName());
		existingCustomer.setPhoneNo(customer.getPhoneNo());

		return repo.save(existingCustomer);

	}

	public Map<String, String> deleteCustomer(Long custId) {
		repo.findById(custId).orElseThrow(() -> new CustomerNotFoundException("Customer not found with ID: " + custId));

		try {
			custInterface.deleteAccByCustomerId(custId);
			repo.deleteById(custId);
			Map<String, String> map = new HashMap<>();
			map.put("message", "Customer is deleted");
			return map;
		} catch (Exception ex) {
			throw new CustomException("Error Deleting Customer");
		}

	}
}
