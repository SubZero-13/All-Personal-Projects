package com.nagarro.Customermanagementservice.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.nagarro.Customermanagementservice.exception.CustomException;
import com.nagarro.Customermanagementservice.exception.CustomerNotFoundException;
import com.nagarro.Customermanagementservice.models.CustomErrorResponse;

@RestControllerAdvice
public class CustomerGlobalExceptionHandler {

	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<?> handleCustomerNotFound(CustomerNotFoundException exception) {

		CustomErrorResponse errorResponse = CustomErrorResponse.builder().status(HttpStatus.INTERNAL_SERVER_ERROR)
				.errorCode(404).errorMessage(exception.getMessage()).build();
		return ResponseEntity.internalServerError().body(errorResponse);

	}

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<?> handleCustomException(CustomException exception) {

		CustomErrorResponse errorResponse = CustomErrorResponse.builder().status(HttpStatus.INTERNAL_SERVER_ERROR)
				.errorCode(404).errorMessage(exception.getMessage()).build();
		return ResponseEntity.internalServerError().body(errorResponse);

	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleGenericException(Exception ex) {
		CustomErrorResponse errorResponse = CustomErrorResponse.builder().status(HttpStatus.INTERNAL_SERVER_ERROR)
				.errorCode(500).errorMessage(ex.getMessage()).build();
		return ResponseEntity.internalServerError().body(errorResponse);
	}

}
