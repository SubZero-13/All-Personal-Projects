package com.nagarro.Customermanagementservice.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.Customermanagementservice.models.Customer;
import com.nagarro.Customermanagementservice.serviceImp.CustomerServiceImpl;

@RestController
@RequestMapping("customer")
public class CustomerController {

	private CustomerServiceImpl customerService;

	@Autowired
	public CustomerController(CustomerServiceImpl customerService) {
		this.customerService = customerService;
	}

	@PostMapping("/add")
	public ResponseEntity<?> addCustomer(@RequestBody Customer customer) {
		Customer newCustomer = customerService.create(customer);

		return new ResponseEntity<>(newCustomer, HttpStatus.CREATED);
	}

	@GetMapping("/getAll")
	public ResponseEntity<?> getCustomers() {

		List<Customer> customers = customerService.getCustomers();

		return new ResponseEntity<>(customers, HttpStatus.OK);
	}

	@GetMapping("/get/{customerId}")
	public ResponseEntity<Customer> getCustomer(@PathVariable Long customerId) {
		Customer currCustomer = customerService.getCustomer(customerId);
		return new ResponseEntity<>(currCustomer, HttpStatus.OK);
	}

	@PutMapping("/update")
	public ResponseEntity<?> updateCustomer(@RequestBody Customer customer) {

		Customer updatedCustomer = customerService.updateCustomer(customer);

		return new ResponseEntity<>(updatedCustomer, HttpStatus.OK);
	}

	@GetMapping("/generate/{customerId}")
	public ResponseEntity<Boolean> isPresent(@PathVariable Long customerId) {
		Boolean isPresent = customerService.isCustomerPresent(customerId);
		return new ResponseEntity<>(isPresent, HttpStatus.OK);
	}

	@DeleteMapping("/delete/{custId}")
	public ResponseEntity<?> deleteCustomer(@PathVariable Long custId) {
		Map<String, String> map = customerService.deleteCustomer(custId);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
