package com.nagarro.Customermanagementservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nagarro.Customermanagementservice.models.Customer;

@Repository
public interface CustomerDao extends JpaRepository<Customer, Long> {

}
