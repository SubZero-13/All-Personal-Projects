package com.nagarro.accountmanagementservice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.accountmanagementservice.models.Account;
import com.nagarro.accountmanagementservice.models.AccountDetailResponse;
import com.nagarro.accountmanagementservice.models.WithdrawalRequest;
import com.nagarro.accountmanagementservice.serviceImpl.AccountServiceImpl;

@RestController
@RequestMapping("account")
public class AccountController {

	private AccountServiceImpl service;

	@Autowired
	public AccountController(AccountServiceImpl service) {
		this.service = service;
	}

	@PostMapping("/add-money")
	public ResponseEntity<?> addMoney(@RequestBody Account accRequest) throws Exception {
		Long customerId = accRequest.getCustomerId();
		service.validateCustomer(customerId);

		Account account = service.addMoney(accRequest);

		return new ResponseEntity<>(account, HttpStatus.OK);
	}

	@PutMapping("/withdraw-money")
	public ResponseEntity<?> withdrawMoney(@RequestBody WithdrawalRequest request) {
		Account account = service.withdrawMoney(request);

		return new ResponseEntity<>(account, HttpStatus.OK);
	}

	@GetMapping("/get-detail/{accountNumber}")
	public ResponseEntity<?> getDetail(@PathVariable Long accountNumber) {
		AccountDetailResponse response = service.getDetail(accountNumber);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("/get-all")
	public ResponseEntity<?> getAllAccDetail() throws Exception {
		List<AccountDetailResponse> responses = service.getAccountList();
		return new ResponseEntity<>(responses, HttpStatus.OK);
	}

	@DeleteMapping("delete/{accNumber}")
	public ResponseEntity<?> deleteAcc(@PathVariable Long accNumber) throws Exception {
		service.deleteAcc(accNumber);
		Map<String, String> accDelete = new HashMap<>();
		accDelete.put("message", "Account Deleted");
		return new ResponseEntity<>(accDelete, HttpStatus.OK);
	}

	@DeleteMapping("deleteByCustId/{customerId}")
	public ResponseEntity<?> deleteAccByCustomerId(@PathVariable Long customerId) throws Exception {
		boolean Isdeleted = service.deleteAccByCustId(customerId);
		return new ResponseEntity<>(Isdeleted, HttpStatus.OK);
	}
}
