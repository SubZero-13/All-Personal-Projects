package com.nagarro.accountmanagementservice.decoder;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class ErrorDecoder {
	
	public String decode(String logMessage) {
			Pattern pattern = Pattern.compile("\"errorMessage\":\"(.*?)\"");
			Matcher matcher = pattern.matcher(logMessage);
			if (matcher.find()) {
				return matcher.group(1);
			}
			return "Customer Not Found";
	}
}
