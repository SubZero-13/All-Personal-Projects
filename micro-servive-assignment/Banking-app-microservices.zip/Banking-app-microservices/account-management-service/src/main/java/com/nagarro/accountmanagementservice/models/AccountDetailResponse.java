package com.nagarro.accountmanagementservice.models;

import lombok.Data;

@Data
public class AccountDetailResponse {
    private Long accNumber;
    private String name;
    private String email;
    private String phoneNo;
    private Long balance;

    public AccountDetailResponse(Account account, Customer customer) {
        this.accNumber = account.getAccNumber();
        this.name = customer.getName();
        this.email = customer.getEmail();
        this.phoneNo = customer.getPhoneNo();
        this.balance = account.getBalance();
    }
}

