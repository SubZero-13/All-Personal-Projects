package com.nagarro.accountmanagementservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nagarro.accountmanagementservice.models.CustomErrorResponse;

@RestControllerAdvice
public class GlobalAccountExceptionHandler {

	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<?> handleCustomerNotFound(CustomerNotFoundException exception) {
		CustomErrorResponse errorResponse = CustomErrorResponse.builder().status(HttpStatus.INTERNAL_SERVER_ERROR)
				.errorCode(404).errorMessage(exception.getMessage()).build();
		return ResponseEntity.internalServerError().body(errorResponse);

	}

	@ExceptionHandler(AccountNotFoundException.class)
	public ResponseEntity<?> handleCustomException(AccountNotFoundException exception) {

		CustomErrorResponse errorResponse = CustomErrorResponse.builder().status(HttpStatus.INTERNAL_SERVER_ERROR)
				.errorCode(404).errorMessage(exception.getMessage()).build();
		return ResponseEntity.internalServerError().body(errorResponse);

	}

	@ExceptionHandler(InsufficientBalanceException.class)
	public ResponseEntity<?> handleInsufficientBalance(InsufficientBalanceException exception) {
		CustomErrorResponse errorResponse = CustomErrorResponse.builder().status(HttpStatus.INTERNAL_SERVER_ERROR)
				.errorCode(404).errorMessage(exception.getMessage()).build();
		return ResponseEntity.internalServerError().body(errorResponse);
	}

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<?> handleCustomException(CustomException exception) {

		CustomErrorResponse errorResponse = CustomErrorResponse.builder().status(HttpStatus.INTERNAL_SERVER_ERROR)
				.errorCode(404).errorMessage(exception.getMessage()).build();
		return ResponseEntity.internalServerError().body(errorResponse);

	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleGenericException(Exception ex) {
		System.out.println(ex.getMessage());
		CustomErrorResponse errorResponse = CustomErrorResponse.builder().status(HttpStatus.INTERNAL_SERVER_ERROR)
				.errorCode(500).errorMessage(ex.getMessage()).build();
		return ResponseEntity.internalServerError().body(errorResponse);

	}

}
