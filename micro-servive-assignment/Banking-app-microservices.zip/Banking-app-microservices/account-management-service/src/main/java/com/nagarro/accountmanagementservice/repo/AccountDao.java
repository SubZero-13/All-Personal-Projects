package com.nagarro.accountmanagementservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nagarro.accountmanagementservice.models.Account;

@Repository
public interface AccountDao extends JpaRepository<Account, Long> {
	boolean existsByCustomerId(Long customerId);
	Account findByCustomerId(Long customerId);
}
