package com.nagarro.accountmanagementservice.models;

import lombok.Data;

@Data
public class WithdrawalRequest {
	private Long accNumber;
	private Long balance;
}
