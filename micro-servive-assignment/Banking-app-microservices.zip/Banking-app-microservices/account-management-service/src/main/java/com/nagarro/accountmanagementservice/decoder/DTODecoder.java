package com.nagarro.accountmanagementservice.decoder;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nagarro.accountmanagementservice.exception.CustomException;
import com.nagarro.accountmanagementservice.models.Customer;

@Component
public class DTODecoder {

	ObjectMapper objectMapper = new ObjectMapper();

	public Customer responseToCustomer(ResponseEntity<?> responseEntity) {
		try {
			Customer customer = objectMapper.convertValue(responseEntity.getBody(), Customer.class);
			return customer;
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage());
		}
	}

	public List<Customer> responseToCustomerList(ResponseEntity<?> responseEntity) {
		try {
			List<Customer> customers = objectMapper.readValue(objectMapper.writeValueAsString(responseEntity.getBody()),
					new TypeReference<List<Customer>>() {
					});
			return customers;
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage());
		}
	}

}
