package com.nagarro.accountmanagementservice.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.nagarro.accountmanagementservice.decoder.DTODecoder;
import com.nagarro.accountmanagementservice.decoder.ErrorDecoder;
import com.nagarro.accountmanagementservice.exception.AccountNotFoundException;
import com.nagarro.accountmanagementservice.exception.CustomException;
import com.nagarro.accountmanagementservice.exception.CustomerNotFoundException;
import com.nagarro.accountmanagementservice.exception.InsufficientBalanceException;
import com.nagarro.accountmanagementservice.feign.AccountServiceInterface;
import com.nagarro.accountmanagementservice.models.Account;
import com.nagarro.accountmanagementservice.models.AccountDetailResponse;
import com.nagarro.accountmanagementservice.models.Customer;
import com.nagarro.accountmanagementservice.models.WithdrawalRequest;
import com.nagarro.accountmanagementservice.repo.AccountDao;

@Service
public class AccountServiceImpl {

	private AccountServiceInterface accServiceInterface;
	private AccountDao repo;
	private DTODecoder dtodecoder;
	private ErrorDecoder errorDecoder;

	@Autowired
	public AccountServiceImpl(AccountServiceInterface accServiceInterface, AccountDao repo, DTODecoder dtodecoder, ErrorDecoder errorDecoder) {
		this.accServiceInterface = accServiceInterface;
		this.repo = repo;
		this.dtodecoder = dtodecoder;
		this.errorDecoder = errorDecoder;
	}

	public Account addMoney(Account acc) {
		Account existingAcc = repo.findByCustomerId(acc.getCustomerId());

		if (existingAcc == null) {
			Account newAcc = new Account();
			newAcc.setBalance(acc.getBalance());
			newAcc.setCustomerId(acc.getCustomerId());
			return repo.save(newAcc);
		} else {
			Long totalBalance = existingAcc.getBalance() + acc.getBalance();
			existingAcc.setBalance(totalBalance);
			return repo.save(existingAcc);
		}
	}

	public Account withdrawMoney(WithdrawalRequest request) {
		Account existingAcc = repo.findById(request.getAccNumber()).orElseThrow(
				() -> new AccountNotFoundException("Account Not Found with this Acc Number:" + request.getAccNumber()));

		if (existingAcc.getBalance() < request.getBalance()) {
			throw new InsufficientBalanceException("Not Enough Money in your Account");
		}
		Long totalBalance = existingAcc.getBalance() - request.getBalance();
		existingAcc.setBalance(totalBalance);
		return repo.save(existingAcc);
	}

	public AccountDetailResponse getDetail(Long accountNumber) {
		Account existingAcc = repo.findById(accountNumber).orElseThrow(
				() -> new AccountNotFoundException("Account Not Found with this Acc Number:" + accountNumber));

		try {
			ResponseEntity<?> responseEntity = accServiceInterface.getCustomer(existingAcc.getCustomerId());
			Customer customer = dtodecoder.responseToCustomer(responseEntity);
			AccountDetailResponse response = new AccountDetailResponse(existingAcc, customer);
			return response;
		} catch (Exception ex) {
			String errorMessage = errorDecoder.decode(ex.getMessage());
			throw new CustomerNotFoundException(errorMessage);
		}

	}

	public void validateCustomer(Long customerId) {
		try {
			accServiceInterface.isPresent(customerId).getBody();
		} catch (Exception ex) {
			String errorMessage = errorDecoder.decode(ex.getMessage());
			throw new CustomerNotFoundException(errorMessage);
		}
	}

	public void deleteAcc(Long accNumber) {
		Account existingAcc = repo.findById(accNumber)
				.orElseThrow(() -> new AccountNotFoundException("Account Not Found with this Acc Number:" + accNumber));

		if (existingAcc.getBalance() > 0) {
			throw new CustomException("Cannot delete account. Please withdraw the balance first.");
		}
		repo.deleteById(accNumber);
	}

	public boolean deleteAccByCustId(Long customerId) {
		Account existingAcc = repo.findByCustomerId(customerId);
		if (existingAcc == null) {
			return true;
		}

		if (existingAcc.getBalance() > 0) {
			throw new CustomException("Cannot delete account. Please withdraw the balance first.");
		}
		try {
			repo.deleteById(existingAcc.getAccNumber());
			return true;
		} catch (Exception e) {
			throw new CustomException("Error Deleting Customer");
		}

	}

	public List<AccountDetailResponse> getAccountList() {
		List<Account> accList = repo.findAll();
		if (accList.size() == 0) {
			throw new CustomException("There is No Accounts in the DB");
		}

		try {
			ResponseEntity<?> responseEntity = accServiceInterface.getCustomers();

			List<Customer> customers = dtodecoder.responseToCustomerList(responseEntity);
			Map<Long, Customer> customerMap = customers.stream()
					.collect(Collectors.toMap(Customer::getId, Function.identity()));
			List<AccountDetailResponse> accountDetailResponses = new ArrayList<>();
			for (Account account : accList) {
				Customer customer = customerMap.get(account.getCustomerId());
				if (customer != null) {
					AccountDetailResponse accountDetailResponse = new AccountDetailResponse(account, customer);
					accountDetailResponses.add(accountDetailResponse);
				}
			}

			return accountDetailResponses;

		} catch (Exception ex) {
			String errorMessage = errorDecoder.decode(ex.getMessage());
			throw new CustomerNotFoundException(errorMessage);
		}
	}
}
