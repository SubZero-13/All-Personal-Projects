import './App.css';
import BlogApp from '../src/components/blogApp/BlogApp'
function App() {
  return (
    <div className="App">
      <BlogApp/>
    </div>
    
  );
}

export default App;
