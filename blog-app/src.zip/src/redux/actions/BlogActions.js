export const initializeData = (data) => ({
  type: 'INITIALIZE_DATA',
  payload: data,
});

export const editBlog = (id, updatedBlog) => ({
  type: 'EDIT_BLOG',
  payload: { id, updatedBlog },
});

export const deleteBlog = (id) => ({
  type: 'DELETE_BLOG',
  payload: id,
});

export const likeBlog = (id) => ({
  type: 'LIKE_BLOG',
  payload: id,
});

// Add the missing addBlog action
export const addBlog = (newBlog) => ({
  type: 'ADD_BLOG',
  payload: newBlog,
});
