// import React, { createContext, useContext, useState, useEffect } from 'react';
// import { ArticleList } from '../config';
// import { useNavigate } from 'react-router-dom';
// const LOCAL_STORAGE_KEY = 'blogAppData';


// const ArticleContext = createContext();

// export function useDataContext() {
//   return useContext(ArticleContext);
// }

// export function DataProvider({ children }) {
//   const navigate = useNavigate();
//   const initialData = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY)) || ArticleList;

//   const [data, setData] = useState(initialData);

//   // Save data to local storage whenever it changes
//   useEffect(() => {
//     localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
//   }, [data]);

//   const addData = (newData) => {
//     // Generate a unique ID for the new article
//     // const id = Date.now();
//     // const articleWithId = { ...newData, id };
//     setData((prevData) => [...prevData, newData]);
//   };

//   const clearSelectedArticle = () => {
//     navigate('/');
//   };

//   return (
//     <ArticleContext.Provider
//       value={{
//         data,
//         addData,
//         clearSelectedArticle,
//       }}
//     >
//       {children}
//     </ArticleContext.Provider>
//   );
// }




import React, { createContext, useContext, useState, useEffect } from 'react';
import { ArticleList } from '../config';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { editBlog, deleteBlog, likeBlog, addBlog } from '../redux/actions/BlogActions';

const LOCAL_STORAGE_KEY = 'blogAppData';

const ArticleContext = createContext();

export function useDataContext() {
  return useContext(ArticleContext);
}

export function DataProvider({ children }) {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const initialData = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY)) || ArticleList;

  const [data, setData] = useState(initialData);

  // Redux state
  const blogs = useSelector((state) => state.blogs);

  // Save data to local storage whenever it changes
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  const addData = (newData) => {
    // Generate a unique ID for the new article
    const id = Date.now();
    const articleWithId = { ...newData, id };
    setData((prevData) => [...prevData, articleWithId]);
    
    // Dispatch action to update Redux state
    dispatch(addBlog(articleWithId));
  };

  const editData = (id, updatedData) => {
    // Find the index of the article in the context data
    const dataIndex = data.findIndex((item) => item.id === id);
    
    // Update the context data
    if (dataIndex !== -1) {
      const newData = [...data];
      newData[dataIndex] = { ...newData[dataIndex], ...updatedData };
      setData(newData);
    }
    
    // Dispatch action to update Redux state
    dispatch(editBlog(id, updatedData));
  };

  const deleteData = (id) => {
    // Remove the article from the context data
    const newData = data.filter((item) => item.id !== id);
    setData(newData);
    
    // Dispatch action to update Redux state
    dispatch(deleteBlog(id));
  };

  const likeData = (id) => {
    const dataIndex = data.findIndex((item) => item.id === id);
    
    // Update the context data
    if (dataIndex !== -1) {
      const newData = [...data];
      newData[dataIndex].likes += 1;
      setData(newData);
    }
    
    // Dispatch action to update Redux state
    dispatch(likeBlog(id));
  };

  const clearSelectedArticle = () => {
    navigate('/');
  };

  return (
    <ArticleContext.Provider
      value={{
        data,
        blogs,
        addData,
        editData,
        deleteData,
        likeData,
        clearSelectedArticle,
      }}
    >
      {children}
    </ArticleContext.Provider>
  );
}

