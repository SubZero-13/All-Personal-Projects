import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useDataContext } from "../../contexts/ArticleContext";

const EditBlog = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { data, editData } = useDataContext();
  const blog = data.find((item) => item.id === parseInt(id)) || {};

  const [formData, setFormData] = useState({
    title: blog.title || "",
    description: blog.description || "",
    content: blog.content || "",
    author: blog.author || "",
  });

  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validation logic (you can add more validation as needed)
    if (!formData.title || !formData.description || !formData.content || !formData.author) {
      setError("All fields are required");
      return;
    }

    // Update the blog data using the context API function
    editData(parseInt(id), formData);

    // Redirect to the BlogDetail page upon successful edit
    navigate(`/blog/${id}`);
  };

  return (
    <div>
      <h2>Edit Blog</h2>
      <form onSubmit={handleSubmit}>
        <input type="hidden" name="id" value={formData.id} />
        <div>
          <label>Title:</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Description:</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Content:</label>
          <textarea
            name="content"
            value={formData.content}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Author Name:</label>
          <input
            type="text"
            name="author"
            value={formData.author}
            onChange={handleChange}
          />
        </div>
        <button type="submit">Submit</button>
      </form>
      {error && <p>{error}</p>}
    </div>
  );
};

export default EditBlog;
