// import React, { useState } from "react";
// import { useDataContext } from "../../contexts/ArticleContext"; 
// const AddBlog = () => {
//   const { addData } = useDataContext();
//   const [formData, setFormData] = useState({
//     title: "",
//     description: "",
//     content: "",
//     author: "",
//   });

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({ ...formData, [name]: value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const id = Date.now();
//     const articleWithId = { ...formData, id };
//     addData(articleWithId);

//     setFormData({
//       title: "",
//       description: "",
//       content: "",
//       author: "",
//     });
//   };

//   return (
//     <div>
//       <h1>Add Article</h1>
//       <form onSubmit={handleSubmit}>
//         <div>
//           <label>Title</label>
//           <input
//             type="text"
//             name="title"
//             value={formData.title}
//             onChange={handleChange}
//             required
//           />
//         </div>
//         <div>
//           <label>Description</label>
//           <input
//             type="text"
//             name="description"
//             value={formData.description}
//             onChange={handleChange}
//             required
//           />
//         </div>
//         <div>
//           <label>Content</label>
//           <textarea
//             name="content"
//             value={formData.content}
//             onChange={handleChange}
//             required
//           />
//         </div>
//         <div>
//           <label>Author</label>
//           <input
//             type="text"
//             name="author"
//             value={formData.author}
//             onChange={handleChange}
//             required
//           />
//         </div>
//         <button type="submit">Submit</button>
//       </form>
//     </div>
//   );
// };

// export default AddBlog;


import React, { useState } from "react";
import { useDataContext } from "../../contexts/ArticleContext";

const AddBlog = () => {
  const { addData } = useDataContext();
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    content: "",
    author: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Add the new blog using the context API function
    addData(formData);

    // Reset the form
    setFormData({
      title: "",
      description: "",
      content: "",
      author: "",
    });
  };

  return (
    <div>
      <h1>Add Article</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Title</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Description</label>
          <input
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Content</label>
          <textarea
            name="content"
            value={formData.content}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Author</label>
          <input
            type="text"
            name="author"
            value={formData.author}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default AddBlog;

