import React from 'react';
import { useDataContext } from '../../contexts/ArticleContext'; 
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { likeBlog } from '../../redux/actions/BlogActions';
const BlogDetail = () => {
  const navigate = useNavigate();
  const { data, clearSelectedArticle, deleteData } = useDataContext();
  const { id } = useParams();
  const article = data.find((article) => article.id === parseInt(id));
  const dispatch = useDispatch();

  const handleEdit = () => {
    navigate(`/blog/${id}/edit`);
  };

  const handleDelete = () => {
    // dispatch(deleteBlog(parseInt(id)));
    deleteData(parseInt(id))
    clearSelectedArticle(); 
  };

  const handleLike = () => {
    dispatch(likeBlog(parseInt(id)));
  };


  if (!article) {
    return <p>Article not found</p>;
  }
  return (
    <div>
      <button onClick={clearSelectedArticle}>Back to List</button>
      <button onClick={handleEdit}>Edit</button>
      <button onClick={handleDelete}>Delete</button>
      <button onClick={handleLike}>Like</button>
      <h2>{article.title}</h2>
      <p>{article.description}</p>
      <p>{article.content}</p>
      <p>Author: {article.author}</p>
      {/* <p>Likes: {article.likes}</p> */}
    </div>
  );
};

export default BlogDetail;
