import React from "react";
import "./layout.css"; 
const Footer = () => {
  return (
    <footer
      className="footer text-center p-3"
    >
      © 2020 Copyright:
      <a className="text-primary" href="https://mdbootstrap.com/">
        Nagarro.com
      </a>
    </footer>
  );
};

export default Footer;
