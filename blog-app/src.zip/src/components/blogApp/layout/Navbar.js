import React from "react";
import { Link } from "react-router-dom";
const Navbar = () => {
  return (
    <nav
      className="navbar navbar-expand-lg bg-primary d-flex flex-row justify-content-between"
      data-bs-theme="dark"
    >
      <Link className="navbar-brand ms-4 font-weight-bold" href="/">
       Nagarro Blog
      </Link>
      
      <Link className="nav-link active m-2" to="/">
        Home
      </Link>
      <Link className="nav-link active m-2" to="/add-blog">
        Add Post
      </Link>
    </nav>
  );
};

export default Navbar;
