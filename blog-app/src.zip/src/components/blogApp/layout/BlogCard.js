import React from "react";
const BlogCard = ({ article }) => {
  return (
    <>
      <div className="card d-flex flex-column flex-wrap justify-content-between m-2">
      <div class="card-body">
        <h2 className="card-title text-break fs-4 text-justify fw-semibold">{article.title}</h2>
        <p className="card-text text-break fs-6 text-justify">{article.description}</p>
      </div>
      </div>
    </>
  );
};

export default BlogCard;
