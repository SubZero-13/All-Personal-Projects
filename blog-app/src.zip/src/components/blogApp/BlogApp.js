import React from 'react'
import Navbar from '../blogApp/layout/Navbar'
import Footer from '../blogApp/layout/Footer'
import { Outlet } from 'react-router-dom'

const BlogApp = () => {
  return (
    <>
      <Navbar/>
      <Outlet/>
      <Footer/>
    </>
  )
}

export default BlogApp